#include <stdio.h>
#include <math.h>
int main()
{
    double x[20000],v[20000],k,m,dt,a,t=0.;
    int i,N;
    printf("\nEnter k,m,dt,N   ");
    scanf("%lf %lf %lf %i",&k,&m,&dt,&N);
    x[0]=5.0;
    v[0]=0.0;
    for (i=0;i<N+1;i++)
    {
        x[i+1]=x[i]+v[i]*dt;
        a=-k*x[i]/m;
        v[i+1]=v[i]+a*dt;
        t=t*dt;
    }
    printf("\nEnter a time step at which you want to know");
    printf("\nthe position and velocity:    ");
    scanf("%d",&i);
    printf("\n The position at step %5i is %8.4lf",i,x[i]);
    printf("\n The velocity at step %5i is %8.4lf\n ",i,v[i]);
}