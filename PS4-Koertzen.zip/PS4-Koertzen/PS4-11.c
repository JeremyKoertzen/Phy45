#include <stdio.h>
#include <math.h>
double myfunction();

int main()
{
    double dx,x,xpp,A,B,C;
    printf("\nEnter x,dx:  ");
    scanf("%lf %lf",&x,&dx);
    A=myfunction(x+dx);
    B=myfunction(x);
    C=myfunction(x-dx);
    xpp= (A-(2*B)+C)/(dx*dx);
    printf("\nThe second derivative of x^4 at x is:  %lf \n",xpp);
    //printf("\nError Check: %lf %lf %lf",A,B,C);
}

double myfunction(double x)
{
    double j;
    j = exp(x) + (2/x);
    return j;
}