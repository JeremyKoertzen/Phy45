#include <stdio.h>
#include <math.h>

int main()
{
    double x,y,E,vx,vy,G=6.67430*pow(10,-11),ms=1.9891*pow(10,30),m=5.97219*pow(10,24),dt,ax,ay,t=0;
    int i,N;
    FILE * fileout;
    fileout=fopen("PS4-1.txt","w");
    printf("\nEnter initial x,y,vx,vy   \n");
    scanf("%lf %lf %lf %lf",&x,&y,&vx,&vy);
    printf("\nEnter dt,N  \n ");
    scanf("%lf %i",&dt,&N);
    fprintf(fileout,"t,x,y,E,vx,vy,ax,ay:\n");
    for(i=0;i<N+1;i++)
    {
        x=x+vx*dt;
        y=y+vy*dt;
        ax=(-G*ms*x)/pow(x*x + y*y,1.5);
        ay=(-G*ms*y)/pow(x*x + y*y,1.5);
        vy=vy+ay*dt;
        vx=vx+ax*dt;
        E=((-G*ms*m)/(pow(x*x + y*y,0.5))) + (0.5*m*(vx*vx + vy*vy));
        t=t+dt;
        fprintf(fileout,"%12.6lf %e %e %e %e %e %e %e  \n",t,x,y,E,vx,vy,ax,ay);
    }
    fclose(fileout);
}