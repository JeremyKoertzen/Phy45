#include <stdio.h>
#include <math.h>

int main()
{
    double x,y,vx,vy,g,m,dt,a,t=0;
    int i,N;
    FILE * fileout;
    fileout=fopen("PS3-7.txt","w");
    printf("\nEnter initial x,y,vx,vy   \n");
    scanf("%lf %lf %lf %lf",&x,&y,&vx,&vy);
    printf("\nEnter g,dt,N  \n ");
    scanf("%lf %lf %i",&g,&dt,&N);
    fprintf(fileout,"Time,x,y,vx,vy:\n");
    do
    {
        x=x+vx*dt;
        y=y+vy*dt;
        a=-g;
        vy=vy+a*dt;
        t=t+dt;
        fprintf(fileout,"%12.6lf %12.6lf %12.6lf %12.6lf %12.6lf \n",t,x,y,vx,vy);
    } while(y>0);
    fclose(fileout);
}