#include <stdio.h>
#include <math.h>

int main()
{
    double x,v,k,m,dt,a,b,t=0;
    int i,N;
    FILE * fileout;
    fileout=fopen("PS3-2.txt","w");
    printf("\nEnter initial x,v   \n");
    scanf("%lf %lf",&x,&v);
    printf("\nEnter k,m,dt,N,b   ");
    scanf("%lf %lf %lf %i %lf",&k,&m,&dt,&N,&b);
    for (i=1; i<N+1; i=i+1)
    {
        x=x+v*dt;
        a=(-k*x - b*v)/m;
        v=v+a*dt;
        t=t+dt;
        fprintf(fileout,"%12.6lf %12.6lf %12.6lf  \n",t,x,v);
    }
    fclose(fileout);
}
