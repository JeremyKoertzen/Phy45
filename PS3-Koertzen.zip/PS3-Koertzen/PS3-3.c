#include <stdio.h>
#include <math.h>

int main()
{
    double x,v,k,m,dt,a,F,t=0;
    int i,N;
    FILE * fileout;
    fileout=fopen("PS3-3.txt","w");
    printf("\nEnter initial x,v,F   \n");
    scanf("%lf %lf %lf",&x,&v,&F);
    printf("\nEnter m,dt,N  \n ");
    scanf("%lf %lf %i",&m,&dt,&N);
    fprintf(fileout,"Time,Position,velocity:\n");
    for (i=1; i<N+1; i=i+1)
    {
        x=x+v*dt;
        a=F/m;
        v=v+a*dt;
        t=t+dt;
        fprintf(fileout,"%12.6lf %12.6lf %12.6lf \n",t,x,v);
    }
    fclose(fileout);
}
