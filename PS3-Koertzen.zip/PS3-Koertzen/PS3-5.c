#include <stdio.h>
#include <math.h>

int main()
{
    double x,v,k,m,b,dt,a,F,t=0;
    int i,N;
    FILE * fileout;
    fileout=fopen("PS3-5.txt","w");
    printf("\nEnter initial x,v,F   \n");
    scanf("%lf %lf %lf",&x,&v,&F);
    printf("\nEnter b,m,dt,N  \n ");
    scanf("%lf %lf %lf %i",&b,&m,&dt,&N);
    fprintf(fileout,"Time,Position,velocity:\n");
    for (i=1; i<N+1; i=i+1)
    {
        x=x+v*dt;
        a=(F-b*v)/m;
        v=v+a*dt;
        t=t+dt;
        fprintf(fileout,"%12.6lf %12.6lf %12.6lf \n",t,x,v);
    }
    fclose(fileout);
}
